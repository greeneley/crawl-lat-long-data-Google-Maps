package crawl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class crawlFile {
    private static String numberAddress;

    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO Auto-generated method stub

        //=================================================
//        File originalFile = new File("geckodriver.exe");
//        String driverName = "geckodriver_" + Calendar.getInstance().getTimeInMillis() + ".exe";
//        Path copied = Paths.get(driverName);
//        Path originalPath = originalFile.toPath();
//        Files.copy(originalPath, copied, StandardCopyOption.REPLACE_EXISTING);
//        File newFile = new File(driverName);
        //==================================================

//        System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\" + driverName);
//        String csvFile = args[0];
        String csvFile = "input.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";

        // ============================

        String nameOutput = csvFile.replace(".csv", "");
        String csvExport = nameOutput + "_result_" + Calendar.getInstance().getTimeInMillis() + ".csv";
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(csvExport), StandardCharsets.UTF_8));
        try {
            br = new BufferedReader(
                new InputStreamReader(
                    new FileInputStream(csvFile), "UTF8"));
            line = br.readLine();
            while ((line = br.readLine()) != null) {

                // =================================================
                WebDriver driver = null;
                JavascriptExecutor js = null;
                // =================================================

                // use comma as separator
                String[] element = line.split(cvsSplitBy);
                int count = 1;
                for (int i = Integer.valueOf(element[2]); i < Integer.valueOf(element[3]) + 1; i++) {
                    if (count == 1) {
                        driver = new FirefoxDriver();
                        js = (JavascriptExecutor) driver;
                        driver.get("https://www.google.com/maps");
                        String newUrl = driver.getCurrentUrl();
                        do {
                            Thread.sleep(5);
                            newUrl = driver.getCurrentUrl();
                        } while (newUrl.contentEquals("https://www.google.com/maps"));
                    }
                    // =================================================
                    driver.findElement(By.id("searchboxinput")).click();
                    driver.findElement(By.id("searchboxinput")).clear();
                    driver.findElement(By.id("searchboxinput")).sendKeys(i + " " + element[0] + " " + element[1]);
                    driver.findElement(By.id("searchbox-searchbutton")).click();

                    String browserUrl = (String) js.executeScript("return decodeURIComponent(window.location.href)");
                    int countSearch = 0;
                    while ((!browserUrl.contains("place")) && countSearch < 5) {
                        TimeUnit.MILLISECONDS.sleep(1000);
                        browserUrl = (String) js.executeScript("return decodeURIComponent(window.location.href)");
                        countSearch++;
                    }
                    // =================================================

                    System.out.println("Your browser URL is " + browserUrl);
                    try {
                        String[] extractString = browserUrl.substring(browserUrl.lastIndexOf("3d") + 2).split("!4d", 2);
                        String address = browserUrl.replaceAll("^.*place/|/@.*$", "").replaceAll("\\+", " ");
                        String regex = "^[0-9]*\\S[0-9]*";
                        Pattern pattern = Pattern.compile(regex);
                        Matcher matcher = pattern.matcher(address);
                        while (matcher.find()) {
                            numberAddress = matcher.group();
                        }
                        address = address.replaceAll(regex, "");
                        CSVUtils.writeLine(writer, Arrays.asList(numberAddress, address.trim(), extractString[0].toString(), extractString[1].toString()));

                        writer.flush();

                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    count++;
                    if (count == 250) {
                        driver.quit();
                        count = 1;
                    }
                }
                driver.quit();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
//        newFile.delete();
        writer.close();
//        Runtime.getRuntime().exec("taskkill /F /IM " + driverName + " /T");
    }
}