package crawl;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class testFunction {

	private static String numberAddress;
	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
//		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"\\chromedriver_win32\\geckodriver.exe");

		WebDriver driver= new FirefoxDriver();
        JavascriptExecutor js = (JavascriptExecutor)driver;
        String csvFile = Calendar.getInstance().getTimeInMillis() + "_result.csv";
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(csvFile), StandardCharsets.UTF_8));
        driver.get("https://www.google.com/maps");

        String newUrl = driver.getCurrentUrl();
        do {
        	Thread.sleep(5);
        	newUrl = driver.getCurrentUrl();
        }while(newUrl.contentEquals("https://www.google.com/maps"));

        for(int i = 1; i < 50; i++) {

        	driver.findElement(By.id("searchboxinput")).click();
            driver.findElement(By.id("searchboxinput")).clear();
            driver.findElement(By.id("searchboxinput")).sendKeys( i + " Nguyễn Văn Linh Đà Nẵng");
            driver.findElement(By.id("searchbox-searchbutton")).click();

            //===================================

            String browserUrl = (String) js.executeScript("return decodeURIComponent(window.location.href)");
            while(!browserUrl.contains("place")){
                TimeUnit.MILLISECONDS.sleep(1000);
                browserUrl = (String) js.executeScript("return decodeURIComponent(window.location.href)");
            }

            //===================================

            System.out.println("Your browser URL is " + browserUrl);
            try {

            	String[] extractString = browserUrl.substring(browserUrl.lastIndexOf("3d")+2).split("!4d", 2);
            	String address = browserUrl.replaceAll("^.*place/|/@.*$", "").replaceAll("\\+", " ").;
        		String regex = "^[0-9]*\\S+[0-9]*";
        		Pattern pattern = Pattern.compile(regex);
        		Matcher matcher = pattern.matcher(address);
//        		String numberAddress = null;
				while(matcher.find()) {
        			numberAddress = matcher.group();
        		}
        		address = address.replaceAll(regex, "");
            	CSVUtils.writeLine(writer, Arrays.asList(numberAddress, address.trim(), extractString[0].toString(), extractString[1].toString()));


            	writer.flush();

            } catch (Exception e) {
				// TODO: handle exception
            	System.out.println(e);;
			}
        }
        driver.close();

	}

}
