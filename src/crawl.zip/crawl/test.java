package crawl;

import java.awt.List;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class test {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		File originalFile = new File("geckodriver.exe");
		String driverName = "geckodriver_" + Calendar.getInstance().getTimeInMillis()+".exe";
		Path copied = Paths.get(driverName);
		Path originalPath = originalFile.toPath();
		Files.copy(originalPath, copied, StandardCopyOption.REPLACE_EXISTING);
		File newFile = new File(driverName);
		Thread.sleep(5000);
        newFile.delete();


	}
}
